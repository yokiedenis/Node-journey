module.exports = Object.freeze({
  LIMIT: 5,
});
